package com.giga.touchstrike;

import android.content.Context;
import android.opengl.GLSurfaceView;
import android.view.MotionEvent;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Color;
import android.view.View;
import android.os.SystemClock;

public final class GameView extends GLSurfaceView {
    private final GameRenderer game;
    private float lookX, lookY, moveX, moveY;
    private int lookPointer = -1, movePointer = -1;
    private final Hud hud;

    public GameView(Context context) {
        super(context);
        setEGLContextClientVersion(2);
        game = new GameRenderer();
        setRenderer(game);
        setRenderMode(GLSurfaceView.RENDERMODE_CONTINUOUSLY);
        hud = new Hud(context);
        // A transparent overlay draws crosshair and touch controls.
        android.widget.FrameLayout frame = new android.widget.FrameLayout(context);
        frame.addView(this);
        frame.addView(hud);
        // GameView is installed directly by Activity, so use a layered container via parent wrapper.
        // The overlay is instead drawn by the renderer's HUD pass for reliable touch handling.
    }

    @Override public boolean onTouchEvent(MotionEvent e) {
        int action = e.getActionMasked();
        int idx = e.getActionIndex();
        float x = e.getX(idx), y = e.getY(idx);
        if (action == MotionEvent.ACTION_DOWN || action == MotionEvent.ACTION_POINTER_DOWN) {
            if (x > getWidth() * 0.72f && y > getHeight() * 0.55f) {
                game.fire();
                lookPointer = e.getPointerId(idx);
                lookX = x; lookY = y;
            } else if (x < getWidth() * 0.42f) {
                movePointer = e.getPointerId(idx);
                moveX = x; moveY = y;
                game.setMove(0, 0);
            } else {
                lookPointer = e.getPointerId(idx);
                lookX = x; lookY = y;
            }
            return true;
        }
        if (action == MotionEvent.ACTION_MOVE) {
            for (int i=0; i<e.getPointerCount(); i++) {
                int id=e.getPointerId(i);
                float px=e.getX(i), py=e.getY(i);
                if (id == movePointer) {
                    float dx=(px-moveX)/(getWidth()*0.13f);
                    float dy=(py-moveY)/(getHeight()*0.18f);
                    game.setMove(clamp(dx), clamp(dy));
                } else if (id == lookPointer) {
                    float dx=px-lookX, dy=py-lookY;
                    game.look(dx*0.22f, dy*0.18f);
                    lookX=px; lookY=py;
                }
            }
            return true;
        }
        if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_POINTER_UP || action == MotionEvent.ACTION_CANCEL) {
            int id=e.getPointerId(idx);
            if (id==movePointer) { movePointer=-1; game.setMove(0,0); }
            if (id==lookPointer) lookPointer=-1;
            return true;
        }
        return true;
    }
    private float clamp(float v) { return Math.max(-1f, Math.min(1f, v)); }

    private static final class Hud extends View {
        private final Paint p = new Paint(3);
        Hud(Context c) { super(c); setLayerType(View.LAYER_TYPE_SOFTWARE, null); }
        @Override protected void onDraw(Canvas c) {
            super.onDraw(c);
            float cx=getWidth()/2f, cy=getHeight()/2f;
            p.setColor(Color.WHITE); p.setStrokeWidth(3);
            c.drawLine(cx-15,cy,cx-5,cy,p); c.drawLine(cx+5,cy,cx+15,cy,p);
            c.drawLine(cx,cy-15,cx,cy-5,p); c.drawLine(cx,cy+5,cx,cy+15,p);
            p.setTextSize(28); c.drawText("MOVE: left side   LOOK: right side   FIRE: tap upper-right", 24, 38, p);
        }
    }
}
