package com.giga.touchstrike;

import android.opengl.GLES20;
import android.opengl.GLSurfaceView;
import android.opengl.Matrix;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.util.Random;
import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

final class GameRenderer implements GLSurfaceView.Renderer {
    private static final String VS =
        "attribute vec3 aPos; uniform mat4 uMvp; void main(){ gl_Position=uMvp*vec4(aPos,1.0); }";
    private static final String FS =
        "precision mediump float; uniform vec4 uColor; void main(){ gl_FragColor=uColor; }";
    private int program, posHandle, mvpHandle, colorHandle;
    private final float[] projection=new float[16], view=new float[16], vp=new float[16], model=new float[16], mvp=new float[16];
    private float yaw=0, pitch=0, moveX=0, moveY=0, px=0, pz=0;
    private int score=0, shots=0;
    private long last=SystemClockCompat.now();
    private final Target[] targets=new Target[8];
    private FloatBuffer cube;
    private final float[] vertices = {
        -0.5f,-0.5f,-0.5f, 0.5f,-0.5f,-0.5f, 0.5f,0.5f,-0.5f, -0.5f,-0.5f,-0.5f, 0.5f,0.5f,-0.5f, -0.5f,0.5f,-0.5f,
        -0.5f,-0.5f,0.5f, 0.5f,0.5f,0.5f, 0.5f,-0.5f,0.5f, -0.5f,-0.5f,0.5f, -0.5f,0.5f,0.5f, 0.5f,0.5f,0.5f,
        -0.5f,-0.5f,-0.5f, -0.5f,0.5f,0.5f, -0.5f,-0.5f,0.5f, -0.5f,-0.5f,-0.5f, -0.5f,0.5f,-0.5f, -0.5f,0.5f,0.5f,
        0.5f,-0.5f,-0.5f, 0.5f,-0.5f,0.5f, 0.5f,0.5f,0.5f, 0.5f,-0.5f,-0.5f, 0.5f,0.5f,0.5f, 0.5f,0.5f,-0.5f,
        -0.5f,0.5f,-0.5f, 0.5f,0.5f,-0.5f, 0.5f,0.5f,0.5f, -0.5f,0.5f,-0.5f, 0.5f,0.5f,0.5f, -0.5f,0.5f,0.5f,
        -0.5f,-0.5f,-0.5f, 0.5f,-0.5f,0.5f, 0.5f,-0.5f,-0.5f, -0.5f,-0.5f,-0.5f, -0.5f,-0.5f,0.5f, 0.5f,-0.5f,0.5f
    };
    GameRenderer() {
        ByteBuffer bb=ByteBuffer.allocateDirect(vertices.length*4).order(ByteOrder.nativeOrder());
        cube=bb.asFloatBuffer(); cube.put(vertices).position(0);
        Random r=new Random(8);
        for(int i=0;i<targets.length;i++) targets[i]=new Target((r.nextFloat()-0.5f)*12f, -7f-r.nextFloat()*18f, 1.1f+r.nextFloat()*0.6f);
    }
    void look(float dx,float dy) { yaw += dx; pitch=Math.max(-65,Math.min(65,pitch+dy)); }
    void setMove(float x,float y) { moveX=x; moveY=y; }
    void fire() {
        shots++;
        float yr=(float)Math.toRadians(yaw), pr=(float)Math.toRadians(pitch);
        float dx=(float)Math.sin(yr), dz=-(float)Math.cos(yr);
        float aimY=(float)Math.sin(pr);
        int best=-1; float bestT=Float.MAX_VALUE;
        for(int i=0;i<targets.length;i++) {
            Target t=targets[i];
            float tx=t.x-px, tz=t.z-pz;
            float along=tx*dx+tz*dz;
            if(along<0 || along>38) continue;
            float side=(float)Math.abs(tx*dz-tz*dx);
            float vertical=Math.abs((t.y-1.0f)-aimY*along);
            if(side < t.size*0.62f && vertical < t.size*0.8f && along<bestT) { best=i; bestT=along; }
        }
        if(best>=0) {
            score++;
            Target t=targets[best];
            t.x=((score*37)%17-8)*0.72f; t.z=-8f-(score%4)*4f; t.size=1.0f+(score%3)*0.25f;
        }
    }
    @Override public void onSurfaceCreated(GL10 gl,EGLConfig config) {
        GLES20.glClearColor(0.055f,0.075f,0.11f,1f);
        GLES20.glEnable(GLES20.GL_DEPTH_TEST);
        int v=shader(GLES20.GL_VERTEX_SHADER,VS), f=shader(GLES20.GL_FRAGMENT_SHADER,FS);
        program=GLES20.glCreateProgram(); GLES20.glAttachShader(program,v); GLES20.glAttachShader(program,f); GLES20.glLinkProgram(program);
        posHandle=GLES20.glGetAttribLocation(program,"aPos"); mvpHandle=GLES20.glGetUniformLocation(program,"uMvp"); colorHandle=GLES20.glGetUniformLocation(program,"uColor");
    }
    private int shader(int type,String src) {
        int s=GLES20.glCreateShader(type); GLES20.glShaderSource(s,src); GLES20.glCompileShader(s); return s;
    }
    @Override public void onSurfaceChanged(GL10 gl,int w,int h) {
        GLES20.glViewport(0,0,w,h); Matrix.perspectiveM(projection,0,72f,(float)w/Math.max(1,h),0.1f,100f);
    }
    @Override public void onDrawFrame(GL10 gl) {
        long now=SystemClockCompat.now(); float dt=Math.min(0.05f,(now-last)/1000f); last=now;
        float yr=(float)Math.toRadians(yaw);
        px += ((float)Math.cos(yr)*moveX + (float)Math.sin(yr)*moveY)*dt*5f;
        pz += ((float)Math.sin(yr)*moveX - (float)Math.cos(yr)*moveY)*dt*5f;
        Matrix.setLookAtM(view,0,px,1.65f,pz,px+(float)Math.sin(yr),1.65f+(float)Math.tan(Math.toRadians(pitch)),pz-(float)Math.cos(yr),0,1,0);
        Matrix.multiplyMM(vp,0,projection,0,view,0);
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT|GLES20.GL_DEPTH_BUFFER_BIT);
        GLES20.glUseProgram(program);
        drawBox(0,-0.2f,-12f,24f,0.3f,42f,0.16f,0.20f,0.25f,1);
        for(int i=-5;i<=5;i++) {
            drawBox(i*2.2f,1f,-22f,0.07f,2f,32f,0.18f,0.23f,0.29f,1);
            drawBox(i*2.2f,0.01f,-12f,0.06f,0.02f,42f,0.32f,0.38f,0.42f,1);
        }
        for(int i=0;i<targets.length;i++) {
            Target t=targets[i];
            drawBox(t.x,t.y,t.z,t.size*0.7f,t.size*1.5f,0.55f,0.9f,0.22f,0.16f,1);
            drawBox(t.x,t.y+t.size*0.95f,t.z, t.size*0.75f,t.size*0.75f,0.65f,1f,0.66f,0.20f,1);
        }
        // Simple weapon silhouette in view-space.
        Matrix.setIdentityM(model,0); Matrix.translateM(model,0,0.42f,-0.32f,-0.8f); Matrix.scaleM(model,0,0.18f,0.14f,0.48f);
        Matrix.multiplyMM(mvp,0,projection,0,model,0); drawRaw(mvp,0.14f,0.16f,0.19f,1);
        Matrix.setIdentityM(model,0); Matrix.translateM(model,0,0.42f,-0.22f,-0.63f); Matrix.scaleM(model,0,0.10f,0.08f,0.18f);
        Matrix.multiplyMM(mvp,0,projection,0,model,0); drawRaw(mvp,0.42f,0.45f,0.48f,1);
        // HUD: score bars and crosshair are rendered as simple 3D line-like boxes.
        drawBox(px+(float)Math.sin(yr)*2f,1.65f+(float)Math.tan(Math.toRadians(pitch))*2f,pz-(float)Math.cos(yr)*2f,0.035f,0.035f,0.035f,1f,1f,1f,1);
    }
    private void drawBox(float x,float y,float z,float sx,float sy,float sz,float r,float g,float b,float a) {
        Matrix.setIdentityM(model,0); Matrix.translateM(model,0,x,y,z); Matrix.scaleM(model,0,sx,sy,sz);
        Matrix.multiplyMM(mvp,0,vp,0,model,0); drawRaw(mvp,r,g,b,a);
    }
    private void drawRaw(float[] matrix,float r,float g,float b,float a) {
        cube.position(0);
        GLES20.glEnableVertexAttribArray(posHandle);
        GLES20.glVertexAttribPointer(posHandle,3,GLES20.GL_FLOAT,false,0,cube);
        GLES20.glUniformMatrix4fv(mvpHandle,1,false,matrix,0);
        GLES20.glUniform4f(colorHandle,r,g,b,a);
        GLES20.glDrawArrays(GLES20.GL_TRIANGLES,0,vertices.length/3);
        GLES20.glDisableVertexAttribArray(posHandle);
    }
    private static final class Target { float x,y,z,size; Target(float x,float z,float s){this.x=x;this.y=1.1f;this.z=z;this.size=s;} }
    private static final class SystemClockCompat { static long now(){ return android.os.SystemClock.uptimeMillis(); } }
}
