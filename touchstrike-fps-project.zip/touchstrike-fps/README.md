# TouchStrike FPS

A small native Android OpenGL ES 2.0 first-person shooting range. It has touch look, left-side movement, targets with head/body hit areas, and a tap-to-fire interaction.

## Prerequisites
- Android Studio (current stable)
- JDK 17
- Android SDK Platform 35 and Build Tools installed
- Android device or emulator with OpenGL ES 2.0

## Build
1. Open this folder in Android Studio.
2. Allow Gradle sync to complete.
3. Connect an Android phone with USB debugging enabled, or choose Build > Build Bundle(s) / APK(s) > Build APK(s).
4. The APK is normally written under `app/build/outputs/apk/debug/`.

CLI: `gradle assembleDebug` (with Android SDK configured).

## Controls
- Drag on the right side to look around.
- Drag on the left side to move.
- Tap the upper-right area to fire.
- Targets respawn after a hit.

## Notes
This is an offline prototype and not a networked multiplayer game. Rendering uses basic geometric shapes. No third-party assets are included.

## Offset disclaimer
No game offsets are used. This project is a standalone Android game, unrelated to Roblox internals.
